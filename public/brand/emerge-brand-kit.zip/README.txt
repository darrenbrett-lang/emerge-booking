EMERGE BRAND KIT
The full guidelines: https://www.emergeunderground.com/brandguidelines

LOGO
The Emerge wordmark is hand-drawn lettering. Never retype it in a font.
emerge-logo-acid.png   Acid on dark grounds. The main version.
emerge-logo-night.png  Night on Acid, Pink or Ivory.
emerge-logo-ivory.png  Ivory on Electric or on a photo darkened behind it.
emerge-icon-512.png    App and social icon.
The PNGs are 1916 px wide, enough for about 160 mm wide in print.
For anything bigger, ask for the vector master.

COLOUR
Night     #171713  RGB 23 23 19
Ivory     #F5F1E8  RGB 245 241 232
Acid      #EFFF00  RGB 239 255 0
Pink      #FF70BC  RGB 255 112 188
Electric  #354BFF  RGB 53 75 255

TYPE (both free from Google Fonts)
Unbounded  Headlines. Bold, ExtraBold, Black. Uppercase, tight tracking.
Work Sans  Everything else. Regular and Bold. Tagline in Bold Italic.

PHOTOGRAPHY
emerge-portrait-photo.jpg     Black and white portrait, full size, no star.
emerge-tooth-star.png         The yellow star, placed to sit on her tooth.
emerge-portrait-with-star.jpg Portrait with the star, web size.
emerge-thermal-*.jpg          The thermal crowd pictures.

LAYOUTS
emerge-flyer-A4.pdf, emerge-flyer-A4-bleed.pdf (3 mm bleed)
emerge-key-visual-square.jpg, emerge-key-visual-4x3.jpg
emerge-instagram-4x5.png
